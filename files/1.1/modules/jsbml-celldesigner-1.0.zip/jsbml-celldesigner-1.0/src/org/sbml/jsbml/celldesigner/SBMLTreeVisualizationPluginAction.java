/*
 * $Id: SBMLTreeVisualizationPluginAction.java 2377 2015-10-09 12:21:58Z niko-rodrigue $
 * $URL: svn+ssh://niko-rodrigue@svn.code.sf.net/p/jsbml/code/trunk/modules/celldesigner/test/org/sbml/jsbml/celldesigner/SBMLTreeVisualizationPluginAction.java $
 * ----------------------------------------------------------------------------
 * This file is part of JSBML. Please visit <http://sbml.org/Software/JSBML>
 * for the latest version of JSBML and more information about SBML.
 * 
 * Copyright (C) 2009-2015 jointly by the following organizations:
 * 1. The University of Tuebingen, Germany
 * 2. EMBL European Bioinformatics Institute (EBML-EBI), Hinxton, UK
 * 3. The California Institute of Technology, Pasadena, CA, USA
 * 4. The University of California, San Diego, La Jolla, CA, USA
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation. A copy of the license agreement is provided
 * in the file named "LICENSE.txt" included with this software distribution
 * and also available online as <http://sbml.org/Software/JSBML/License>.
 * ----------------------------------------------------------------------------
 */
package org.sbml.jsbml.celldesigner;

import java.awt.event.ActionEvent;

import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.xml.stream.XMLStreamException;

/**
 * @author Andreas Dr&auml;ger
 * @version $Rev: 2377 $
 * @since 1.0
 * @date 16.04.2014
 */
public class SBMLTreeVisualizationPluginAction extends AbstractCellDesignerPluginAction {

  /**
   * Generated serial version identifier.
   */
  private static final long serialVersionUID = -2317705894273036740L;

  /**
   * The plugin that is triggered when this object receives appropriate actions.
   */
  private final SBMLTreeVisualizationPlugin plugin;

  /**
   * 
   * @param plugin
   */
  public SBMLTreeVisualizationPluginAction(SBMLTreeVisualizationPlugin plugin) {
    super(plugin);
    this.plugin = plugin;
  }

  /* (non-Javadoc)
   * @see jp.sbi.celldesigner.plugin.PluginActionListener#myActionPerformed(java.awt.event.ActionEvent)
   */
  @Override
  public void myActionPerformed(ActionEvent evt) {
    if (!plugin.isStarted())
    {
      plugin.setStarted(true);
    }

    if (evt.getSource() instanceof JMenuItem) {
      JMenuItem item = (JMenuItem) evt.getSource();
      if (item.getText().equals(SBMLTreeVisualizationPlugin.ACTION)) {
        try {
          plugin.startPlugin();
        } catch (XMLStreamException exc) {
          JOptionPane.showMessageDialog(item, exc.getMessage(),
            exc.getClass().toString(), JOptionPane.ERROR_MESSAGE);
          exc.printStackTrace();
        }
      }
    } else {
      JOptionPane.showMessageDialog(null, "Unsupported source of action "
          + evt.getSource().getClass().getName(), "Invalid Action",
          JOptionPane.WARNING_MESSAGE);
    }
  }

}
