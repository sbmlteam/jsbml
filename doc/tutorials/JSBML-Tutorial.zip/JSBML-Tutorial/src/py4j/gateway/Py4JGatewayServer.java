package py4j.gateway;

import py4j.GatewayServer;

/**
 * Starts the gateway <a href="https://www.py4j.org/">Py4J</a> server so that Python can communicate
 * with a running java virtual machine.
 * 
 * @author rodrigue
 *
 */
public class Py4JGatewayServer {

  /**
   * @param args no arguments expected
   */
  public static void main(String[] args) {
    GatewayServer gatewayServer = new GatewayServer(null);
    gatewayServer.start();
    System.out.println("Gateway Server Started");
    
    try {
      GatewayServer.main(null);
    } catch (NullPointerException e) {}
  }

}


