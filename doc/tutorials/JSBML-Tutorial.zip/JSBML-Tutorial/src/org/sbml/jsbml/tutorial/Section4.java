package org.sbml.jsbml.tutorial;

import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.SBMLReader;
import org.sbml.jsbml.SBMLWriter;

public class Section4 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws XMLStreamException 
	 */
	public static void main(String[] args) throws XMLStreamException, IOException {
		
		String filePathSeparator = System.getProperty("file.separator");
		
		SBMLReader sbmlReader = new SBMLReader();
		
		System.out.println("Trying to read invalid-syntax.xml\n");
		try {
			SBMLDocument doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "invalid-syntax.xml");

			doc.checkConsistency(); // calling the libSBML online validator
			
			System.out.println("\n");
			doc.printErrors(System.out); // Printing the content of the ErrorLog on the console

		} catch(Exception e) {
			System.out.println("Exception encountered : " + e.getMessage());
		}

		System.out.println("\nTrying to read invalid-sbml-syntax.xml\n");
		try {
			SBMLDocument doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "invalid-sbml-syntax.xml");
			
			doc.checkConsistency(); // calling the libSBML online validator
			
			System.out.println("\n");
			doc.printErrors(System.out);

		} catch(Exception e) {
			System.out.println("Exception encountered : " + e.getMessage());
		}

		System.out.println("\nTrying to read invalid-general.xml\n");
		try {
			SBMLDocument doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "invalid-general.xml");
			
			doc.checkConsistency(); // calling the libSBML online validator
			
			System.out.println("\n");
			doc.printErrors(System.out);
			
		} catch(Exception e) {
			System.out.println("Exception encountered : " + e.getMessage());
		}
}

}













