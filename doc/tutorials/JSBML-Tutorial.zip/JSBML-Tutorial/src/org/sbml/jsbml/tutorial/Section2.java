package org.sbml.jsbml.tutorial;

import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.sbml.jsbml.Model;
import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.SBMLReader;
import org.sbml.jsbml.Species;


public class Section2 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws XMLStreamException 
	 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws XMLStreamException, IOException {

		String filePathSeparator = System.getProperty("file.separator");
		
		SBMLReader sbmlReader = new SBMLReader();
		SBMLDocument doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "simple.xml");
		
		Model model = doc.getModel();
		int nbSpecies = model.getNumSpecies();
		
		System.out.println("Nb Species = " + nbSpecies);
		
		Species s1 = model.getSpecies(0);
		
		System.out.println("Name : " + s1 + ", java class name : " + s1.getClass().getName());
		
		System.out.println("S1 id = " + s1.getId());
				
		boolean isSetInitialAmount = s1.isSetInitialAmount();
		
		if (isSetInitialAmount) {
			System.out.println("S1 initial amount = " + s1.getInitialAmount());
		}
		
		if (s1.isSetSubstanceUnits()) {
			System.out.println("S1 substance units = " + s1.getSubstanceUnits());
		} else {
			// No default defined in SBML L3 so you can get null here
			System.out.println("S1 substance units = " + s1.getDerivedUnitDefinition());
		}

		Model m2 = new SBMLDocument(2,4).createModel();
		Species newSpecies = new Species(2, 4);
		m2.addSpecies(newSpecies);
		System.out.println("newSpecies L2V4 substance units = " + newSpecies.getDerivedUnitDefinition());
	}

}
































