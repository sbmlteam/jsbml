package org.sbml.jsbml.tutorial;

import javax.xml.stream.XMLStreamException;

import org.sbml.jsbml.ASTNode;
import org.sbml.jsbml.AssignmentRule;
import org.sbml.jsbml.Compartment;
import org.sbml.jsbml.JSBML;
import org.sbml.jsbml.Model;
import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.SBMLException;
import org.sbml.jsbml.SBMLWriter;
import org.sbml.jsbml.Species;
import org.sbml.jsbml.text.parser.ParseException;

public class Section3 {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws SBMLException, XMLStreamException, ParseException {
		
		// creating a new SBML document for SBML level 3 version 1.
		SBMLDocument doc = new SBMLDocument(3, 1);
		
		// Using the create methods
		Model model = doc.createModel("testModel"); 

		Compartment compartment = model.createCompartment("cell");
		Species s1 = model.createSpecies();
		Species s2 = model.createSpecies("S2", "Species 2", compartment);
		
		System.out.println("nb compartment = " + model.getNumCompartments());
		System.out.println("nb species = " + model.getNumSpecies());
		
		// The method toSBML() does not exist in JSBML
		// so you have to create the whole document
		SBMLWriter sbmlWriter = new SBMLWriter();
		
		// Printing the created document to the console
		System.out.println(sbmlWriter.writeSBMLToString(doc));
		
		// Using setter methods
		compartment.setConstant(true);
		compartment.setSpatialDimensions(3);
		compartment.setSize(1);
		
		System.out.println(compartment.writeXMLAttributes());
		
		// A quick way to add math elements
		ASTNode ast = JSBML.parseFormula("a + b - c");

		System.out.println(ast.toMathML()); // or JSBML.writeMathMLToString(ast)
		
		// Having created the ASTNode, it can be added to any class containing some math
		// (interface MathContainer)
		AssignmentRule as = new AssignmentRule();
		as.setMath(ast);
	}
}















































