package org.sbml.jsbml.tutorial.soluce;

import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.sbml.jsbml.Compartment;
import org.sbml.jsbml.JSBML;
import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.Species;

public class Solution5 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws XMLStreamException 
	 */
	public static void main(String[] args) throws XMLStreamException, IOException {

		String filePathSeparator = System.getProperty("file.separator");

		// 1.	The file 'invalid-syntax.xml' needs to be corrected by hand, with a text editor.
		
		// 2.	The file 'invalid-sbml-syntax.xml' could be corrected by merely writing it out as 
		// JSBML will have ignored the invalid SBML. Although this would not be a fail safe method.

		 SBMLDocument doc = JSBML.readSBML("sbml-files" + filePathSeparator + "invalid-sbml-syntax.xml");
		 JSBML.writeSBML(doc, "invalid-sbml-syntax-corrected.xml");
		 
		 
		// 3.	The file 'invalid-general.xml' could be corrected using code.

		 doc = JSBML.readSBML("sbml-files" + filePathSeparator + "invalid-general.xml");
		 Compartment comp = doc.getModel().getCompartment(0);
		 Species species = doc.getModel().getSpecies(0);
		 species.setCompartment(comp.getId());
		 JSBML.writeSBML(doc, "invalid-general-corrected.xml");

	}

}
