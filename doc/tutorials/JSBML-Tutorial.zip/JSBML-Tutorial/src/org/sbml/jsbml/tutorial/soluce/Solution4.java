package org.sbml.jsbml.tutorial.soluce;

import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.sbml.jsbml.Compartment;
import org.sbml.jsbml.JSBML;
import org.sbml.jsbml.KineticLaw;
import org.sbml.jsbml.Model;
import org.sbml.jsbml.Parameter;
import org.sbml.jsbml.Reaction;
import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.SBMLException;
import org.sbml.jsbml.Species;
import org.sbml.jsbml.SpeciesReference;
import org.sbml.jsbml.Unit;
import org.sbml.jsbml.UnitDefinition;
import org.sbml.jsbml.text.parser.ParseException;

public class Solution4 {

	/**
	 * @param args
	 * @throws XMLStreamException 
	 * @throws SBMLException 
	 * @throws ParseException 
	 * @throws IOException 
	 */
	@SuppressWarnings({ "deprecation" })
	public static void main(String[] args) throws SBMLException, XMLStreamException, ParseException, IOException {

		SBMLDocument doc = new SBMLDocument(3,1);
		Model model = doc.createModel();

		// Compartment
		Compartment comp = model.createCompartment();
		comp.setId("cell");
		comp.setSize(0.5);
		comp.setConstant(true);

		// Species
		Species species1 = model.createSpecies();
		species1.setId("A");
		species1.setCompartment("cell");
		species1.setInitialAmount(0.15);
		species1.setConstant(false);
		species1.setBoundaryCondition(false);
		species1.setHasOnlySubstanceUnits(false);

		Species species2 = model.createSpecies("B", "B", comp);
		species2.setInitialAmount(3.2e-4);
		species2.initDefaults(2, 4); // Set the same values as for species1 but does not write them back to the file !

		Species species3 = model.createSpecies("C", "C", comp);
		species3.setInitialAmount(1);
		species3.initDefaults(2, 4);

		Species species4 = model.createSpecies("D", "D", comp);
		species4.setInitialAmount(0);
		species4.initDefaults(2, 4);

		// Parameters
		Parameter param1 = model.createParameter();
		param1.setId("p1");
		param1.setValue(20);
		param1.setConstant(true);

		Parameter param2 = model.createParameter("p2");
		param2.setValue(100);
		param2.setConstant(true);

		// Reactions
		Reaction react1 = model.createReaction();
		react1.setId("R1");
		react1.setReversible(false);
		react1.setFast(false);

		SpeciesReference reactant = react1.createReactant();
		reactant.setSpecies("A");
		reactant.setStoichiometry(1);
		reactant.setConstant(true);

		SpeciesReference product = react1.createProduct();
		product.setSpecies("B");
		product.setStoichiometry(2);
		product.setConstant(true);

		KineticLaw kineticLaw = react1.createKineticLaw();
		kineticLaw.setFormula("cell * A * p1");

		Reaction react2 = model.createReaction("R2");
		react2.setReversible(false);
		react2.setFast(false);

		SpeciesReference reactant2 = react2.createReactant(species3);
		reactant2.setStoichiometry(2);
		reactant2.setConstant(true);

		SpeciesReference product2 = react2.createProduct(species4);
		product2.setStoichiometry(1);
		product2.setConstant(true);

		KineticLaw kineticLaw2 = react2.createKineticLaw();
		kineticLaw2.setFormula("cell * D * p2");

		JSBML.writeSBML(doc, "exercise4.xml");
		// The file "exercise4.xml" is in the sbml-files folder.

		// ADDITIONAL CODE TO ADD UNITS:
		comp.setUnits("litre");
		species1.setUnits("mole");
		species2.setUnits("mole");
		species3.setUnits("mole");
		species4.setUnits("mole");

		UnitDefinition unitDefinition = model.createUnitDefinition();
		unitDefinition.setId("per_sec");

		Unit unit = unitDefinition.createUnit();
		unit.setKind(Unit.Kind.SECOND);
		unit.setScale(0);
		unit.setMultiplier(1);
		unit.setExponent(-1);

		param1.setUnits("per_sec");
		param2.setUnits("per_sec");

		model.setTimeUnits("second");
		model.setExtentUnits("mole");

		JSBML.writeSBML(doc, "exercise4WithUnits.xml");

	}

}
