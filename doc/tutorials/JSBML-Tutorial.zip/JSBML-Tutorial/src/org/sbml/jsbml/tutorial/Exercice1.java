package org.sbml.jsbml.tutorial;

public class Exercice1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO : Read in the example model 'simple.xml' and determine how
		// many of each subelement are present within the model.

	}

}
