package org.sbml.jsbml.tutorial.soluce;

import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.sbml.jsbml.Model;
import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.SBMLReader;

public class Solution1 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws XMLStreamException 
	 */
	public static void main(String[] args) throws XMLStreamException, IOException {

		String filePathSeparator = System.getProperty("file.separator");
		
		SBMLReader sbmlReader = new SBMLReader();
		SBMLDocument doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "simple.xml");
		
		Model model = doc.getModel();
		int nbSpecies = model.getNumSpecies();
		
		System.out.println("Nb FunctionDefinitions = " + model.getNumFunctionDefinitions());
		System.out.println("Nb UnitDefinitions = " + model.getUnitDefinitionCount());
		System.out.println("Nb Compartments = " + model.getListOfCompartments().size());
		System.out.println("Nb Species = " + nbSpecies);
		System.out.println("Nb Parameters = " + model.getParameterCount());
		System.out.println("Nb InitialAssignments = " + model.getNumInitialAssignments());
		System.out.println("Nb Rules = " + model.getRuleCount());
		System.out.println("Nb Constraints = " + model.getConstraintCount());
		System.out.println("Nb Reactions = " + model.getReactionCount());
		System.out.println("Nb Events = " + model.getListOfEvents().size());
		
	}

}
