package org.sbml.jsbml.tutorial;

public class Exercice3 {

	public static void main(String[] args) {
		/*
		 
		  TODO 
		  
		  Read in the simple.xml file, change it in the following ways and 
		  then write out the resulting document [using JSBML.writeSBML(doc, filename) ].
		  
		   - Change the name of the compartment to be "C".
		   - Change the initialAmount of species S2 to 0.15.
		   - Unset the value of the parameter.
		   - Change the stoichiometry of S1 in the reaction to 2.

		 */
	}
}
