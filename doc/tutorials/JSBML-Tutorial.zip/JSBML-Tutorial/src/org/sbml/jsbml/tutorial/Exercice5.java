package org.sbml.jsbml.tutorial;

public class Exercice5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*

		TODO
		
		Corrected the three invalid SBML models : invalid-syntax.xml, invalid-sbml-syntax.xml
		and invalid-general.xml. Note, the first one has to be corrected by hand with a text editor.
		
		 
		 */
	}

}
