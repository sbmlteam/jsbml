package org.sbml.jsbml.tutorial.soluce;

import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.sbml.jsbml.Compartment;
import org.sbml.jsbml.Model;
import org.sbml.jsbml.Parameter;
import org.sbml.jsbml.Reaction;
import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.SBMLReader;
import org.sbml.jsbml.SBMLWriter;
import org.sbml.jsbml.Species;
import org.sbml.jsbml.SpeciesReference;

public class Solution3 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws XMLStreamException 
	 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws XMLStreamException, IOException {

		String filePathSeparator = System.getProperty("file.separator");

		// 1. Read in simple.xml
		SBMLReader sbmlReader = new SBMLReader();
		SBMLDocument doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "simple.xml");
		
		Model model = doc.getModel();
		
		// 2. Change the name of the first compartment to be 'C'
		if (model.getCompartmentCount() >= 1) {
			Compartment comp = model.getCompartment(0);
			comp.setName("C");
		}

		// 3. Change the initialAmount of species S2 to 0.15
		Species s2 = model.getSpecies("S2");
		if (s2 != null) {
			s2.setInitialAmount(0.15);
		}


		// 4. Unset the value of the first parameter.
		if (model.getParameterCount() >= 1) {
			Parameter p1 = model.getParameter(0);
			p1.unsetValue();
		}

		
		// 5. Change the stoichiometry of S1 in the reaction to 2.
		if (model.getNumReactions() >= 1) {
			Reaction reaction = model.getReaction(0);
			
			SpeciesReference speciesReference = reaction.getReactantForSpecies("S1");
			
			if (speciesReference == null) {
				speciesReference = reaction.getProductForSpecies("S1");
			}
			if (speciesReference != null) {
				speciesReference.setStoichiometry(2);
			}
		}
		
		
		SBMLWriter sbmlWriter = new SBMLWriter();
		
		// Printing the modified document to the console
		System.out.println(sbmlWriter.writeSBMLToString(doc));

		// Save the modified document tp a file
		sbmlWriter.writeSBMLToFile(doc, "sbml-files" + filePathSeparator + "simple-modified.xml");
	}

}
