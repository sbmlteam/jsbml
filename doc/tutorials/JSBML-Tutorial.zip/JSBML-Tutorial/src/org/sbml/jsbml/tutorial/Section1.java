package org.sbml.jsbml.tutorial;

import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.SBMLReader;


public class Section1 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws XMLStreamException 
	 */
	public static void main(String[] args) throws XMLStreamException, IOException {

		String filePathSeparator = System.getProperty("file.separator");
		String currentDir = System.getProperty("user.dir");
		
		SBMLReader sbmlReader = new SBMLReader();
		SBMLDocument doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "simple.xml");
		
		System.out.println(doc);
		
		System.out.println("The current working directory is : " + currentDir);
	}

}
