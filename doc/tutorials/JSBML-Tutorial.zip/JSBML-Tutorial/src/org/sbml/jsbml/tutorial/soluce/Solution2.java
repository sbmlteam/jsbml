package org.sbml.jsbml.tutorial.soluce;

import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import org.sbml.jsbml.Compartment;
import org.sbml.jsbml.Model;
import org.sbml.jsbml.Parameter;
import org.sbml.jsbml.Reaction;
import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.SBMLReader;
import org.sbml.jsbml.Species;
import org.sbml.jsbml.SpeciesReference;

public class Solution2 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws XMLStreamException 
	 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws XMLStreamException, IOException {

		String filePathSeparator = System.getProperty("file.separator");
		
		SBMLReader sbmlReader = new SBMLReader();
		SBMLDocument doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "simple.xml");
		
		Model model = doc.getModel();

		// i. What are the spatial dimensions of the first compartment ? -> Answer: 3
		if (model.getCompartmentCount() >= 1) {
			Compartment comp = model.getCompartment(0);
			if (comp.isSetSpatialDimensions()) {
				System.out.println("First compartment spatialDimensions = " + comp.getSpatialDimensions());
			} else {
				System.out.println("First compartment spatialDimensions attribute is undefined");
			}
		}

		// ii. Is the reaction with id "R1" a fast reaction ? -> Answer: false
		Reaction r1 = model.getReaction("R1");
		
		if (r1 != null) {
			if (r1.isSetFast()) {
				System.out.println("The fast attribute on reaction R1 is set to '" + r1.isFast() + "'");
			} else {
				System.out.println("The fast attribute on reaction R1 is undefined");
			}
		}
		
		// iii. What are the substanceUnits of the second species ? -> Answer: not set
		if (model.getNumSpecies() >= 2) {
			Species s2 = model.getSpecies(1);
			if (s2.isSetSubstanceUnits()) {
				System.out.println("Second species substanceUnits = " + s2.getSubstanceUnits());
			} else {
				System.out.println("Second species substanceUnits attribute is undefined");
			}
		}
		
		// iv. Is the first parameter constant ? -> Answer: true
		if (model.getParameterCount() >= 1) {
			Parameter p1 = model.getParameter(0);
			if (p1.isSetConstant()) {
				System.out.println("First parameter is contant = " + p1.isConstant());
			} else {
				System.out.println("First parameter constant attribute is undefined");
			}
		}
		
		// v. What is the name of the parameter with id "k1" ? -> Answer: Param1
		Parameter k1 = model.getParameter("k1");
		
		if (k1 != null) {
			if (k1.isSetName()) {
				System.out.println("The name attribute on parameter k1 is set to '" + k1.getName() + "'");
			} else {
				System.out.println("The name attribute on parameter k1 is undefined");
			}
		}
		
		// vi. How many products are there in the first reaction ? -> Answer: 1
		if (model.getNumReactions() >= 1) {
			Reaction firstReaction = model.getReaction(0);
			
			System.out.println("There is " + firstReaction.getNumProducts() + " products in the first reaction");
		
			
			// vii. What is the stoichiometry of the first reactant in the first reaction ? -> Answer: 1
			if (firstReaction.getListOfReactants().size() > 0) {
				SpeciesReference reactant = firstReaction.getReactant(0);
				if (reactant.isSetStoichiometry()) {
					System.out.println("first reactant of first reaction stoichiometry = " + reactant.getStoichiometry());
				} else {
					System.out.println("first reactant of first reaction stoichiometry attribute is undefined ");
				}
			}
			
			
			// viii. What is the infix formula representation of the kineticLaw in the first reaction ?
			// -> Answer: compartment * k1 * S1
			if (firstReaction.isSetKineticLaw()) {
				System.out.println("first reaction kineticLaw = " + firstReaction.getKineticLaw().getMath().toFormula());
			}
		}
	}

}
