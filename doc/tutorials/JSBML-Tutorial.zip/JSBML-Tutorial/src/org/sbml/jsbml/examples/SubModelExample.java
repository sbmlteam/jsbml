package org.sbml.jsbml.examples;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import javax.xml.stream.XMLStreamException;

import org.identifiers.registry.RegistryUtilities;
import org.sbml.jsbml.CVTerm.Qualifier;
import org.sbml.jsbml.Reaction;
import org.sbml.jsbml.SBMLDocument;
import org.sbml.jsbml.SBMLReader;
import org.sbml.jsbml.SBMLWriter;
import org.sbml.jsbml.TidySBMLWriter;
import org.sbml.jsbml.util.SubModel;

/**
 * This class is an example of how to extract a submodel from an existing model. It will read an input file
 * that contains some KEGG reaction ids, will filter the SBML reactions annotated with one of the KEGG ids and
 * will create a submodel with those reactions.
 * 
 * <p>You need to have a least java 1.8 to be able to run this example.</p>
 * 
 * 
 * @author rodrigue
 * @since 1.3
 */
public class SubModelExample {
  
  public static String KEGG_IDS_FILE= "sbml-files/kegg_ids";
  
  public static String INPUT_MODEL= "sbml-files/BMID000000101165.xml";
  
  public static String OUTPUT_SUB_MODEL= "sbml-files/submodel.xml";
  
  public static void main(String[] args) throws IOException, XMLStreamException {
    
    //
    // Reading the input file and creating a java set containing all the kegg ids.
    //
    Set<String> keggIdSet = new HashSet<String>();

    // The following lines are java 1.8 compatible.
    try (Stream<String> stream = Files.lines(Paths.get(KEGG_IDS_FILE))) {
      stream.forEach(new Consumer<String>() {

        @Override
        public void accept(String line) {
          if (line.trim().length() > 0) {
            // System.out.println(line);
            keggIdSet.add(line);
          }
        }});
    }
    
    //
    // Reading the SBML input file
    //
    SBMLDocument doc = new SBMLReader().readSBML(INPUT_MODEL);
   
    //
    // Going throw all reactions
    //
    // creating a list to hold the reaction ids that match one of the kegg ids.
    List<String> matchingReactionList = new ArrayList<String>();
    
    for (Reaction reaction : doc.getModel().getListOfReactions()) {
      
      // checking that the reaction has some annotations before doing any further search
      if (reaction.getCVTermCount() > 0) {
        
        // Going through all the annotation and filtering only the URI that contain 'kegg'
        List<String> keggUris = reaction.filterCVTerms(Qualifier.BQB_IS, ".*kegg.*");
        
        if (keggUris != null && keggUris.size() > 0) {
          for (String keggUri : keggUris) {
            
            // Using the identifiers.org registry library to extract the identifier without to worry of the form of the URI.
            String reactionKeggId = RegistryUtilities.getElementPart(keggUri);
            
            if (keggIdSet.contains(reactionKeggId)) {
              // We found a matching reaction, we store it's id to use it later to create the submodel.
              matchingReactionList.add(reaction.getId());
              break;
            }
          }
        }
      }
    }
    
    
    //
    // Creating a submodel
    //
    if (matchingReactionList.size() > 0) {
      
      System.out.println("Found " + matchingReactionList.size() + " reactions corresponding to the given kegg ids.");

      SBMLDocument subModel = SubModel.generateSubModel(doc.getModel(), null, null, matchingReactionList.toArray(new String[matchingReactionList.size()]));
      
      if (subModel != null) {
        // 
        // Writing the submodel back to file
        //
        System.out.println("Writing the submodel into '" + OUTPUT_SUB_MODEL + "'.");
        new TidySBMLWriter().writeSBMLToFile(subModel, OUTPUT_SUB_MODEL);
      }
    } else {
      System.out.println("Unfortunately, we did not find any matching reaction, no submodel created.");
    }
    
  }
}
