
from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm

# Answer programmatically to the following questions about the SBML model defined 
# in simple.xml :
		
# 	i. What are the spatial dimensions of the first compartment ?
# 	ii. Is the reaction with id "R1" a fast reaction ?
# 	iii. What are the substanceUnits of the second species ?
# 	iv. Is the first parameter constant ?
# 	v. What is the name of the parameter with id "k1" ?

# 	(a bit harder)
		
# 	vi. How many products are there in the first reaction ?
# 	vii. What is the stoichiometry of the first reactant in the first reaction ?
# 	viii. What is the infix formula representation of the kineticLaw in the first reaction ?

#		
# -----------------------------------------------------------------------------------------------
#

# i.
# - get the first compartment in the model class		
# - check if the spatial dimension attribute is set
# - if it is set, get it and print it. Otherwise, print a warning message.
		
# Write the code for the first question below 


		
# ii. 
# - get the reaction with id "R1"
# ...
		
# Write the code for the second question below 
