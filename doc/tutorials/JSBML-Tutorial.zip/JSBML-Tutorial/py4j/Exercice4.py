
from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm


from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm


#
# Create an SBMLDocument that represents four species A, B, C & D
# in a compartment cell. Two irreversible non-fast reactions occur
# such that :
# 	R1: A -> 2B, kineticLaw = cell * A * p1
# 	R2: 2C -> D, kineticLaw = cell * D * p2

# where p1 and p2 are parameters. Initial values in the model are 
# given below. To be extra clever add the units to your model.
# 	______________________________		
# 	| ID        |     Value      |
# 	|___________|________________|
# 	|           |		     |
# 	| A	    | 0.15 mole	     |
# 	| B	    | 3.2e-4 mole    |
# 	| C	    | 1 mole	     |
# 	| D	    | 0 mole	     |
# 	| cell	    | 0.5 litre	     |
# 	| p1	    | 20 s-1	     |
# 	| p2	    | 100 s-1	     |
# 	|___________|________________| 	
#
#


