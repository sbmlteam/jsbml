
from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm

#
# Corrected the three invalid SBML models : invalid-syntax.xml, invalid-sbml-syntax.xml
# and invalid-general.xml. 
#
# Note, the first one has to be corrected by hand with a text editor.
#

