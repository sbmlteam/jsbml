
from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm


# Read in the simple.xml file, change it in the following ways and 
# then write out the resulting document [using JSBML.writeSBML(doc, filename) ].

#  - Change the name of the compartment to be "C".
#  - Change the initialAmount of species S2 to 0.15.
#  - Unset the value of the parameter.
#  - Change the stoichiometry of S1 in the reaction to 2.


# 1. Read in simple.xml

# Ask java which character to use in a file path so that it work on both windows and Linux
filePathSeparator = jvm.java.lang.System.getProperty("file.separator"); 

# Creating the SBMLreader instance
sbmlReader = jvm.org.sbml.jsbml.SBMLReader();

# Reading the simple.xml file into an SBMLDocument instance
# TODO - check the path, may be put the full path if needed
doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "simple.xml");

# Retriving the Model instance
model = doc.getModel();


# 2. Change the name of the first compartment to be 'C'
comp = model.getCompartment(0);
comp.setName("C");


# 3. Change the initialAmount of species S2 to 0.15
s2 = model.getSpecies("S2");
if (s2 != None):
    s2.setInitialAmount(0.15)

# 4. Unset the value of the first parameter.
p1 = model.getParameter(0);
p1.unsetValue()


# 5. Change the stoichiometry of S1 in the reaction to 2.
reaction = model.getReaction(0);

speciesReference = reaction.getReactantForSpecies("S1");
			
if (speciesReference == None):
    speciesReference = reaction.getProductForSpecies("S1");

if (speciesReference != None):
    speciesReference.setStoichiometry(2.0);


# 6. writing out the resulting document

sbmlWriter = jvm.org.sbml.jsbml.SBMLWriter();
		
# Printing the modified document to the console
print sbmlWriter.writeSBMLToString(doc)

# Save the modified document to a file
jvm.org.sbml.jsbml.JSBML.writeSBML(doc, os.getcwd() + filePathSeparator + "sbml-files" + filePathSeparator + "simple-modified.xml");
