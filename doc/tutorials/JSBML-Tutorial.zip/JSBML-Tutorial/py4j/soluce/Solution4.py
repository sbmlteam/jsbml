
from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm


#
# Create an SBMLDocument that represents four species A, B, C & D
# in a compartment cell. Two irreversible non-fast reactions occur
# such that :
# 	R1: A -> 2B, kineticLaw = cell * A * p1
# 	R2: 2C -> D, kineticLaw = cell * D * p2

# where p1 and p2 are parameters. Initial values in the model are 
# given below. To be extra clever add the units to your model.
# 	______________________________		
# 	| ID        |     Value      |
# 	|___________|________________|
# 	|           |		     |
# 	| A	    | 0.15 mole	     |
# 	| B	    | 3.2e-4 mole    |
# 	| C	    | 1 mole	     |
# 	| D	    | 0 mole	     |
# 	| cell	    | 0.5 litre	     |
# 	| p1	    | 20 s-1	     |
# 	| p2	    | 100 s-1	     |
# 	|___________|________________| 	
#
#
				
# Creating a new empty SBMLDocument instance
doc = jvm.org.sbml.jsbml.SBMLDocument(3, 1)

# Creating the Model instance
model = doc.createModel("M");

# Creating the Compartment
comp = model.createCompartment();
comp.setId("cell");
comp.setSize(0.5);
comp.setConstant(True);

# Creating the Species
species1 = model.createSpecies();
species1.setId("A");
species1.setCompartment("cell");
species1.setInitialAmount(0.15);
species1.setConstant(False);
species1.setBoundaryCondition(False);
species1.setHasOnlySubstanceUnits(False);

species2 = model.createSpecies("B", "B", comp);
species2.setInitialAmount(3.2e-4);
species2.initDefaults(2, 4); # Set the same values as for species1 but does not write them back to the file !

species3 = model.createSpecies("C", "C", comp);
species3.setInitialAmount(1.);
species3.initDefaults(2, 4);

species4 = model.createSpecies("D", "D", comp);
species4.setInitialAmount(0.);
species4.initDefaults(2, 4);

# Creating the Parameters
param1 = model.createParameter();
param1.setId("p1");
param1.setValue(20.);
param1.setConstant(True);

param2 = model.createParameter("p2");
param2.setValue(100.);
param2.setConstant(True);

# Creating the Reactions
react1 = model.createReaction();
react1.setId("R1");
react1.setReversible(False);
react1.setFast(False);

reactant = react1.createReactant();
reactant.setSpecies("A");
reactant.setStoichiometry(1.);
reactant.setConstant(True);

product = react1.createProduct();
product.setSpecies("B");
product.setStoichiometry(2.);
product.setConstant(True);

kineticLaw = react1.createKineticLaw();
kineticLaw.setFormula("cell * A * p1");

react2 = model.createReaction("R2");
react2.setReversible(False);
react2.setFast(False);

reactant2 = react2.createReactant(species3);
reactant2.setStoichiometry(2.);
reactant2.setConstant(True);

product2 = react2.createProduct(species4);
product2.setStoichiometry(1.);
product2.setConstant(True);

kineticLaw2 = react2.createKineticLaw();
kineticLaw2.setFormula("cell * D * p2");

		
# Printing the document to the console
sbmlWriter = jvm.org.sbml.jsbml.SBMLWriter();
print sbmlWriter.writeSBMLToString(doc)

# Saving the document to a file
jvm.org.sbml.jsbml.JSBML.writeSBML(doc, os.getcwd() + filePathSeparator + "sbml-files" + filePathSeparator + "exercise4.xml");
# The file "exercise4.xml" is saved in the sbml-files folder.

#
# Additional code to add units:
#
comp.setUnits("litre");
species1.setUnits("mole");
species2.setUnits("mole");
species3.setUnits("mole");
species4.setUnits("mole");

unitDefinition = model.createUnitDefinition();
unitDefinition.setId("per_sec");

unit = unitDefinition.createUnit();
unit.setKind(jvm.org.sbml.jsbml.Unit.Kind.SECOND);
unit.setScale(0);
unit.setMultiplier(1.);
unit.setExponent(-1.);

param1.setUnits("per_sec");
param2.setUnits("per_sec");

model.setTimeUnits("second");
model.setExtentUnits("mole");


# Printing the modified document to the console
print sbmlWriter.writeSBMLToString(doc)

# Save the modified document to a file
jvm.org.sbml.jsbml.JSBML.writeSBML(doc, os.getcwd() + filePathSeparator + "sbml-files" + filePathSeparator + "exercise4WithUnits.xml");
