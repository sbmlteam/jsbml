
from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm

# Answer programmatically to the following questions about the SBML model defined 
# in simple.xml :
		
# 	i. What are the spatial dimensions of the first compartment ?
# 	ii. Is the reaction with id "R1" a fast reaction ?
# 	iii. What are the substanceUnits of the second species ?
# 	iv. Is the first parameter constant ?
# 	v. What is the name of the parameter with id "k1" ?

# 	(a bit harder)
		
# 	vi. How many products are there in the first reaction ?
# 	vii. What is the stoichiometry of the first reactant in the first reaction ?
# 	viii. What is the infix formula representation of the kineticLaw in the first reaction ?

#		
# -----------------------------------------------------------------------------------------------
#

# Ask java which character to use in a file path so that it work on both windows and Linux
filePathSeparator = jvm.java.lang.System.getProperty("file.separator"); 

# Creating the SBMLreader instance
sbmlReader = jvm.org.sbml.jsbml.SBMLReader();

# Reading the simple.xml file into an SBMLDocument instance
# TODO - check the path, may be put the full path if needed
doc = sbmlReader.readSBMLFromFile("sbml-files" + filePathSeparator + "simple.xml");

# Retriving the Model instance
model = doc.getModel();


# i.
# - get the first compartment in the model class		
# - check if the spatial dimension attribute is set
# - if it is set, get it and print it. Otherwise, print a warning message.
		
# code for the first question below 

# What are the spatial dimensions of the first compartment ? -> Answer: 3
if (model.getCompartmentCount() >= 1):
    comp = model.getCompartment(0)
    if (comp.isSetSpatialDimensions()):
        print "First compartment spatialDimensions = ", comp.getSpatialDimensions()
    else:
        print  "First compartment spatialDimensions attribute is undefined"
		
# ii. 
# - get the reaction with id "R1"
# ...
		
# code for the second question below 

# Is the reaction with id "R1" a fast reaction ? -> Answer: false
r1 = model.getReaction("R1");

if (r1 != None):
    if (r1.isSetFast()):
        print "The fast attribute on reaction R1 is set to '", r1.isFast(),  "'"
    else:
        print "The fast attribute on reaction R1 is undefined"



# iii. What are the substanceUnits of the second species ? -> Answer: not set

if (model.getNumSpecies() >= 2):
    s2 = model.getSpecies(1)
    if (s2.isSetSubstanceUnits()):
        print "Second species substanceUnits = ",  s2.getSubstanceUnits()
    else:
        print "Second species substanceUnits attribute is undefined"


# iv. Is the first parameter constant ? -> Answer: true
if (model.getParameterCount() >= 1):
    p1 = model.getParameter(0)
    if (p1.isSetConstant()):
        print "First parameter is contant = ", p1.isConstant()
    else:
        print "First parameter constant attribute is undefined"


# v. What is the name of the parameter with id "k1" ? -> Answer: Param1

k1 = model.getParameter("k1")

if (k1 != None):
    if (k1.isSetName()):
        print "The name attribute on parameter k1 is set to '", k1.getName(), "'"
    else:
        print "The name attribute on parameter k1 is undefined"


# vi. How many products are there in the first reaction ? -> Answer: 1

if (model.getNumReactions() >= 1):
    firstReaction = model.getReaction(0)    
    print "There is ", firstReaction.getNumProducts(), " products in the first reaction")
		

# vii. What is the stoichiometry of the first reactant in the first reaction ? -> Answer: 1

if (r1.getListOfReactants().size() > 0):
    reactant = r1.getReactant(0)
    if (reactant.isSetStoichiometry()):
        print "First reactant of first reaction stoichiometry = ", reactant.getStoichiometry()
    else:
        print "First reactant of first reaction stoichiometry attribute is undefined "
		
# viii. What is the infix formula representation of the kineticLaw in the first reaction ? -> Answer: compartment * k1 * S1

if (r1.isSetKineticLaw()):
    print "first reaction kineticLaw = ", r1.getKineticLaw().getMath().toFormula()


