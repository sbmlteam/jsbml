
import os
from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm

#
# Corrected the three invalid SBML models : invalid-syntax.xml, invalid-sbml-syntax.xml
# and invalid-general.xml. 
#
# Note, the first one has to be corrected by hand with a text editor.
#


# Ask java which character to use in a file path so that it work on both windows and Linux
filePathSeparator = jvm.java.lang.System.getProperty("file.separator"); 

# 1. The file 'invalid-syntax.xml' needs to be corrected by hand, with a text editor.


# 2. The file 'invalid-sbml-syntax.xml' could be corrected by merely writing it out as 
# JSBML will have ignored the invalid SBML. Although this would not be a fail safe method.


# Reading the file into an SBMLDocument instance
doc = jvm.org.sbml.jsbml.JSBML.readSBML(os.getcwd() + filePathSeparator + "sbml-files" + filePathSeparator + "invalid-sbml-syntax.xml");
# Writing it into a new file
jvm.org.sbml.jsbml.JSBML.writeSBML(doc, os.getcwd() + filePathSeparator + "sbml-files" + filePathSeparator + "invalid-sbml-syntax-corrected.xml");



# 3. The file 'invalid-general.xml' could be corrected using code.
doc = jvm.org.sbml.jsbml.JSBML.readSBML(os.getcwd() + filePathSeparator + "sbml-files" + filePathSeparator + "invalid-general.xml");
comp = doc.getModel().getCompartment(0);
species = doc.getModel().getSpecies(0);
species.setCompartment(comp.getId());

# Writing the modified SBMLDocument into a new file
jvm.org.sbml.jsbml.JSBML.writeSBML(doc, os.getcwd() + filePathSeparator + "sbml-files" + filePathSeparator + "invalid-general-corrected.xml");
