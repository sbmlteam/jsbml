
# the java current directory is relative to where the py4j server was started
# below is a way to change it to be the same as the python 'os.getcwd()'
import os;
directory = jvm.java.io.File(os.getcwd()).getAbsoluteFile();
if (directory.exists() or directory.mkdirs()):
    jvm.java.lang.System.setProperty("user.dir", directory.getAbsolutePath())

# Now the java current directory is changed to the python current directory
file = jvm.java.io.file("sbml-files" + filePathSeparator + "simple-modified.xml")

print file.getAbsolutePath()
