from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm

# Read in the example model 'simple.xml' and determine how
# many of each subelements are present within the model.

# Ask java which character to use in a file path so that it work on both windows and Linux
filePathSeparator = jvm.java.lang.System.getProperty("file.separator"); 

# Creating the SBMLreader instance
sbmlReader = jvm.org.sbml.jsbml.SBMLReader();

# Reading the simple.xml file into an SBMLDocument instance
# TODO - check the path in the following line, may be put the full path. 
# If you did not start your python session from a folder that contain the 'sbml-files' folder, you will
# have to replace 'os.getcwd()' by the full path of the folder that contain the 'sbml-files' folder.
doc = sbmlReader.readSBMLFromFile(os.getcwd() + filePathSeparator + "sbml-files" + filePathSeparator + "simple.xml");

# Retriving the Model instance
model = doc.getModel();
nbSpecies = model.getNumSpecies();

# Printing the number of subelements
print "Nb FunctionDefinitions = ",  model.getNumFunctionDefinitions()
print "Nb UnitDefinitions = ",  model.getUnitDefinitionCount()
print "Nb Compartments = ",  model.getListOfCompartments().size()
print "Nb Species = ",  nbSpecies
print "Nb Parameters = ",  model.getParameterCount()
print "Nb InitialAssignments = ",  model.getNumInitialAssignments()
print "Nb Rules = ",  model.getRuleCount()
print "Nb Constraints = ",  model.getConstraintCount()
print "Nb Reactions = ",  model.getReactionCount()
print "Nb Events = ",  model.getListOfEvents().size()

