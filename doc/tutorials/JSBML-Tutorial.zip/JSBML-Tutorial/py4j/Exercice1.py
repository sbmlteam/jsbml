
from py4j.java_gateway import JavaGateway

jvm = gateway = JavaGateway().jvm

# TODO : Read in the example model 'simple.xml' and determine how
# many of each subelement are present within the model.

